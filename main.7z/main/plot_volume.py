from deepeval.test_case import LLMTestCaseParams
from deepeval.metrics.dag import (
    DeepAcyclicGraph,
    TaskNode,
    BinaryJudgementNode,
    NonBinaryJudgementNode,
    VerdictNode,
)
from deepeval.metrics import DAGMetric


#情节体量打分 非二叉
plot_volume = NonBinaryJudgementNode(
    criteria="Rate the degree to which characters and setting are transformed through the course of 'actual_output'.",
    children=[
        VerdictNode(verdict="no change",score=1),
        VerdictNode(verdict="trivial change",score=2),
        VerdictNode(verdict="moderate change",score=3),
        VerdictNode(verdict="significant change",score=4),
        VerdictNode(verdict="life-altering,dramatic change",score=5)
    ]
)

volume_ = TaskNode(
    instructions="Analyze the plot volume of 'actual_output' based on decision tree analysis.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    output_label="Score the story's plot volume.",
    children=[plot_volume]
)

dag = DeepAcyclicGraph(root_nodes=[volume_])
volume_metric= DAGMetric(name="plot_volume", dag=dag)