from deepeval.test_case import LLMTestCaseParams
from deepeval.metrics.dag import (
    DeepAcyclicGraph,
    TaskNode,
    BinaryJudgementNode,
    NonBinaryJudgementNode,
    VerdictNode,
)
from deepeval.metrics import DAGMetric

#角色发展打分 非二叉
character_development = NonBinaryJudgementNode(
    criteria="""We define character development in terms of
 changes that a character undergoes through the
 course of narrative events.
 Wedefine changes broadly to include cognitive,
 emotional, behavioral, spiritual, moral, bodily, and
 social changes.
 Notably, we do not consider environmental
 changes for characters sufficient for character de
velopment, but acknowledge that other types of
 change (e.g. emotional, social) often accompany or are caused by environmental changes.Rate the narrator’s character development based
 on the following scale.
    """,
    children = [
        VerdictNode(verdict="no change",score=1),
        VerdictNode(verdict="limited change",score=2),
        VerdictNode(verdict="moderate change",score=3),
        VerdictNode(verdict="significant change",score=4),
        VerdictNode(verdict="life-altering, dramatic change",score=5)
    ]
)

development = TaskNode(
    instructions="Analyze the plot volume of 'actual_output' based on decision tree analysis.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    output_label="Score the story's plot volume.",
    children=[character_development]
)

dag = DeepAcyclicGraph(root_nodes=[development])
development_metric= DAGMetric(name="development", dag=dag)