from deepeval.test_case import LLMTestCaseParams
from deepeval.metrics.dag import (
    DeepAcyclicGraph,
    TaskNode,
    BinaryJudgementNode,
    NonBinaryJudgementNode,
    VerdictNode,
)
from deepeval.metrics import DAGMetric


#角色认知的表述打分 非二叉
cognition = NonBinaryJudgementNode(
    criteria="""Rating Prominence of Cognitive Process Descriptions.Rate how prominently the story includes descriptions of cognitive processes, defined as explicit statements that reveal the narrator’s mental state, thinking patterns, reasoning, or internal deliberation (not just factual recollection or external actions). Use the scale below:
Rating Scale:
No cognitive process description(1)
Example: "I grew up in a small town." (pure factual recollection; no mental state/thinking revealed)
Rationale: Focuses on objective facts or external events, not internal cognition.
Minor/Implicit cognitive process description(1)
Example: "I hesitated before answering." (implies mild internal thought but does not explicitly describe it)
Rationale: Suggests some mental activity (e.g., hesitation, doubt) but does not articulate the narrator’s thoughts or feelings.

Moderate/Explicit cognitive process description(3)
Example: "I wondered if she had lied to me, but I pushed the thought aside." (clear articulation of a specific thought or mental conflict)
Rationale: Explicitly reveals a mental state (e.g., wonder, doubt) or thinking pattern (e.g., conflict, decision-making).

Prominent/Detailed cognitive process description(5)
Example: "I spent hours weighing the pros and cons, torn between accepting the offer and staying in my comfort zone. Every time I visualized the new job, anxiety crept in—what if I failed? But staying meant missing a once-in-a-lifetime opportunity." (extended exploration of complex thoughts, emotions, and reasoning)
Rationale: Provides detailed insight into the narrator’s internal dialogue, emotional conflicts, or analytical processes over time.
Key Clarifications
Exclude factual recollection: Statements like "I remembered my birthday" (rating = 1) are not cognitive processes unless they include how the narrator feels about or reasons about the memory (e.g., "I remembered my birthday with a mix of nostalgia and dread" = rating ≥3).
Focus on the narrator’s perspective: Evaluate only the narrator’s explicit mental states, not inferred thoughts of other characters unless the narrator directly articulates them.
 """,
    children=[
        VerdictNode(verdict="minimal or no cognitive processes",score=1),
        VerdictNode(verdict="moderate prominence of cognitive processes",score=3),
        VerdictNode(verdict="high prominence of cognitive processes",score=5)
    ]
)

cognition_ = TaskNode(
    instructions="Analyze the cognitive processes of 'actual_output' based on decision tree analysis.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    output_label="Score the story's the cognitive processes.",
    children=[cognition]
)

dag = DeepAcyclicGraph(root_nodes=[cognition_])
cognition_metric= DAGMetric(name="cognition", dag=dag)