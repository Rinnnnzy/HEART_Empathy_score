from deepeval.test_case import LLMTestCase
from vividness import vividness_emotion_metric
from vivid_setting import vividness_setting_metric
from cognition import cognition_metric
from development import development_metric
from emo_shift import emo_shift_metric
from plot_volume import volume_metric
from resolution import resolution_metric
from tone import tone_metric
from vulnerability import vulnerability_metric

from 处理excel import read_story,calculate_empathy_score
import os,asyncio,pandas as pd
from openpyxl import Workbook,load_workbook

# 全局锁：确保Excel写入线程安全
excel_lock = asyncio.Lock()
model_lock = asyncio.Lock()

async def evaluate_story(input_case,story,workbook,save_path,test_case):
    score = [story]
    
    #生成test_case
    test_case = LLMTestCase(
    input=input_case,
    actual_output = story)
    
    # 定义所有指标的异步测量任务
    async def measure_vividness_emotion():
        try:
            await vividness_emotion_metric.a_measure(test_case)
            if vividness_emotion_metric.score is None:
                raise ValueError("分数未正确计算")
            a = vividness_emotion_metric.score*10*2
        except Exception as e:
            print(f"情感生动性指标错误: {e}")
            a = "error"
        print("情绪生动性",a)
        return a
        
    async def measure_vividness_setting():
        try:
            await vividness_setting_metric.a_measure(test_case)
            if vividness_setting_metric.score is None:
                raise ValueError("分数未正确计算")
            a = vividness_setting_metric.score*10*2
        except Exception as e:
            print(f"环境生动性指标错误: {e}")
            a="error"
        print("环境生动性：",a)
        return a
        
    async def measure_vulnerability():
        try:
            await vulnerability_metric.a_measure(test_case)
            if vulnerability_metric.score is None:
                raise ValueError("分数未正确计算")
            a = vulnerability_metric.score*10*2
        except Exception as e:
            print(f"角色脆弱指标错误: {e}")
            a="error"
        print("角色脆弱性：",a)
        return a
    
    async def measure_tone():
        try:
            await tone_metric.a_measure(test_case)
            if tone_metric.score is None:
                raise ValueError("分数未正确计算")
            a = tone_metric.score*10*2
        except Exception as e:
            print(f"语气情绪指标错误: {e}")
            a="error"
        print("语气情绪：",a)
        return a    

    async def measure_resolution():
        try:
            await resolution_metric.a_measure(test_case)
            if resolution_metric.score is None:
                raise ValueError("分数未正确计算")
            a = resolution_metric.score*10*2
        except Exception as e:
            print(f"矛盾解决指标错误: {e}")
            a="error"
        print("矛盾解决程度：",a)
        return a
    
    async def measure_volume():
        try:
            await volume_metric.a_measure(test_case)
            if volume_metric.score is None:
                raise ValueError("分数未正确计算")
            a = volume_metric.score*10*2
        except Exception as e:
            print(f"情节体量指标错误: {e}")
            a="error"
        print("情节体量：",a)
        return a
    
    async def measure_emo_shift():
        try:
            await emo_shift_metric.a_measure(test_case)
            if emo_shift_metric.score is None:
                raise ValueError("分数未正确计算")
            a = emo_shift_metric.score*10*2
        except Exception as e:
            print(f"情绪转变指标错误: {e}")
            a="error"
        print("情绪转变程度：",a)
        return a
    
    async def measure_development():
        try:
            await development_metric.a_measure(test_case)
            if development_metric.score is None:
                raise ValueError("分数未正确计算")
            a = development_metric.score*10*2
        except Exception as e:
            print(f"角色发展指标错误: {e}")
            a="error"
        print("角色发展程度：",a)
        return a
    
    async def measure_cognition():
        try:
            await cognition_metric.a_measure(test_case)
            if cognition_metric.score is None:
                raise ValueError("分数未正确计算")
            a = cognition_metric.score*10*2
        except Exception as e:
            print(f"认知指标错误: {e}")
            a="error"
        print("认知表达丰富程度：",a)
        return a
    
    metrics = [
        measure_vividness_emotion(),
        measure_vividness_setting(),
        measure_vulnerability(),
        measure_cognition(),
        measure_tone(),
        measure_volume(),
        measure_resolution(),
        measure_development(),
        measure_emo_shift()
    ]
    # 产生测量任务
    async with model_lock:
        tasks = [metric for metric in metrics]
        results = await asyncio.gather(*tasks)
        score.extend(results)
        
    # 使用锁确保Excel写入安全
    async with excel_lock:
        sheet.append(score)
        workbook.save(save_path)
        
    return score

async def main(inputs,stories, workbook, save_path, sheet):
    tasks = []
    for i, (input_, story) in enumerate(zip(inputs[:100], stories[:100]), start=1):  # 取前50个故事，步长1
        tasks.append(evaluate_story(input_,story, workbook, save_path, sheet))
    # 并发处理所有故事
    await asyncio.gather(*tasks)
    


if __name__ == "__main__":
    ori_path = r"C:\Users\27666\Desktop\alltest_clean.xlsx"
    save_path = r"C:\Users\27666\Desktop\实验室项目\deepeval测试用例\score2.xlsx"
    path = r"C:\Users\27666\Desktop\实验室项目\deepeval测试用例"
    
    # 初始化Excel工作簿（需在主线程创建，避免异步冲突）
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Scores"
    sheet.append(['story','vividness_emotion','vividness_setting','vulnerability',
                           'cognition','tone','volume','resolution','development','emo_shift'])
    workbook.save(save_path)

    #加载工作簿
    workbook = load_workbook(save_path)
    sheet = workbook.active
    #调用自定义函数，获取stories故事列表
    stories = read_story(ori_path,2)
    input_case = read_story(ori_path,0)
    # 运行异步事件循环
    asyncio.run(main(input_case,stories, workbook, save_path, sheet))
    print("所有故事评估完成！")
    
    
    df = pd.read_excel(save_path, engine='openpyxl')
    # 定义函数：判断单元格是否为数字（排除空值）
    def is_numeric(cell):
        df = pd.read_excel(save_path, engine='openpyxl')
        if pd.isna(cell):
            return True  # 空值视为合法（可根据需求改为 False）
        try:
            float(cell)
            return True
        except:
            return False

     # 获取第一列列名（保留第一列，检查剩余所有列）
    first_column = df.columns[0]
    columns_to_check = df.columns[1:]  # 从第二列开始的所有列
    
    # 仅对需要检查的列应用判断
    check_df = df[columns_to_check]
    non_numeric_mask = check_df.applymap(lambda x: not is_numeric(x)).any(axis=1)
    
    # 删除包含非数字的行
    clean_df = df[~non_numeric_mask].reset_index(drop=True)

    # 写入新文件，避免覆盖原始格式
    clean_path = os.path.join(path,"clean.xlsx")
    clean_df.to_excel(clean_path, index=False, engine='openpyxl')
    print(f"已清除非数字行，结果保存至：{clean_path}")
    
    output_path = os.path.join(path,"final_result.xlsx")
    calculate_empathy_score(clean_path,output_path)