from deepeval.test_case import LLMTestCaseParams
from deepeval.metrics.dag import (
    DeepAcyclicGraph,
    TaskNode,
    BinaryJudgementNode,
    NonBinaryJudgementNode,
    VerdictNode,
)
from deepeval.metrics import DAGMetric

##情绪生动性程度打分 非二叉
vividness_of_emotions = NonBinaryJudgementNode(
    criteria ="""Rate the vividness of emotions described in 'actual_output'. For example, vividness can be characterized by metaphor, simile, imagery, or strong language.
    Examples:
 • I didn’t feel great about the situation. (1)
 • Hewasahard-hitter in business, but outside
 of work he was completely different. (2)
 • The pain of losing someone is like being
 stabbed in the chest. I was devasted when
 I lost her. (3)
 • I was totally exhausted, tears running down
 myface (3).
    """,
    children=[
        VerdictNode(verdict="not vivid at all",score=1),
        VerdictNode(verdict="somewhat vivid",score=3),
        VerdictNode(verdict="very vivid",score=5)
    ]
)

##是否有情绪词 二叉
exsitance_of_emotions = BinaryJudgementNode(
    criteria="有无情绪描写出现",
    children=[
        VerdictNode(verdict=False,score=0),
        VerdictNode(verdict=True,child=vividness_of_emotions)
    ]
)

vividness_emotion= TaskNode(
    instructions="Analyze the vividness of emotions of 'actual_output' based on decision tree analysis.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    output_label="Score the story's the vividness of emotions.",
    children=[exsitance_of_emotions,vividness_of_emotions]
)

dag = DeepAcyclicGraph(root_nodes=[vividness_emotion])
vividness_emotion_metric= DAGMetric(name="vividness of emotion", dag=dag)