from deepeval.test_case import LLMTestCase
from deepeval.dataset import EvaluationDataset,dataset

from vividness import vividness_emotion_metric
from vivid_setting import vividness_setting_metric
from cognition import cognition_metric
from development import development_metric
from emo_shift import emo_shift_metric
from plot_volume import volume_metric
from resolution import resolution_metric
from tone import tone_metric
from vulnerability import vulnerability_metric


dataset1 = EvaluationDataset()

# Add as test cases(来源deepeval官网)
dataset1.add_test_cases_from_csv_file(
    # file_path is the absolute path to you .csv file
    file_path=r"C:\Users\27666\Desktop\test_case1.csv",
    input_col_name="input",
    actual_output_col_name="output",
    context_col_delimiter= ".",
)

from deepeval import evaluate
from deepeval.dataset import EvaluationDataset

dataset = EvaluationDataset(dataset1)

import sys

# 定义输出文件路径（建议使用绝对路径或相对路径）
output_file = r"C:\Users\27666\Desktop\output.txt"

# 重定向标准输出和错误到文件（使用 'a' 以追加模式写入，'w' 为覆盖模式）
with open(output_file, "w", encoding="utf-8") as f:
    sys.stdout = f  # 重定向标准输出
    
    #批量测试文件（没有emo_shift)
    batch_size = 5
    for i in range(0, len(dataset.test_cases), batch_size):
        batch = dataset.test_cases[i:i+batch_size]
        batch_dataset = EvaluationDataset(test_cases=batch)
        batch_dataset.evaluate([vividness_emotion_metric,vividness_setting_metric,vulnerability_metric
                  ,tone_metric,resolution_metric,volume_metric,development_metric,cognition_metric])  # 传入指标列表
