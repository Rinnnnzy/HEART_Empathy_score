from deepeval.test_case import LLMTestCaseParams
from deepeval.metrics.dag import (
    DeepAcyclicGraph,
    TaskNode,
    BinaryJudgementNode,
    NonBinaryJudgementNode,
    VerdictNode,
)
from deepeval.metrics import DAGMetric

#环境描写生动性程度打分 非二叉
vividness_of_setting = NonBinaryJudgementNode(
    criteria="""Rate the vividness of the setting described in 'actual_output'. For example, vividness can be characterized by metaphor, simile, imagery, or strong language. 
Examples:
 • I went to the restaurant to grab a bite to eat.(1)
 • The sun cast warm rays onto the concrete in
 the park. (3)
 • The waves in Palos Verdes crashed against the
 shore, making beautiful ribbons (3)
 • There was a house, with music playing in it
 (2)""",
    children=[
        VerdictNode(verdict="not vivid at all",score=1),
        VerdictNode(verdict="somewhat vivid",score=3),
        VerdictNode(verdict="very vivid",score=5)
    ]
)


vividness_setting= TaskNode(
    instructions="Analyze the vividness of setting of 'actual_output' based on decision tree analysis.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    output_label="Score the story's the vividness of setting.",
    children=[vividness_of_setting]
)

dag = DeepAcyclicGraph(root_nodes=[vividness_setting])
vividness_setting_metric= DAGMetric(name="vividness of setting", dag=dag)