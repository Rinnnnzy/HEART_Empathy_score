from deepeval.test_case import LLMTestCaseParams
from deepeval.metrics.dag import (
    DeepAcyclicGraph,
    TaskNode,
    BinaryJudgementNode,
    NonBinaryJudgementNode,
    VerdictNode,
)
from deepeval.metrics import DAGMetric

#叙述者的语气情绪 非二叉
optimistic_tone=NonBinaryJudgementNode(
    criteria="""Rate the level of optimistic/pessimistic tone in the
 narrator’s story. This should be the tone from the
 narrator’s perspective, not of other characters in the
 story. Examples:
 • I feel alone. It is so frustrating. I used to
 be fine with it, but then for some reason I
 actually started wanting to have a friend. I
 have nobody. And nobody around me seems
 interesting enough to me. Life gets boring.
 And frustrating. (rating =-2, very pessimistic)
 • He is grown up and I have done my job to
 get him out into the world. I will miss his
 teenage years (somewhat), but I am proud of
 him. (rating = 2, very optimistic)""",
    children=[
        VerdictNode(verdict="very pessimistic",score=1),
        VerdictNode(verdict="somewhat pessimistic",score=2),
        VerdictNode(verdict="neutral",score=3),
        VerdictNode(verdict="somewhat optimistic",score=4),
        VerdictNode(verdict="very optimistic",score=5)
    ]
)

tone = TaskNode(
    instructions="Analyze the optimistic/pessimistic tone of 'actual_output' based on decision tree analysis.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    output_label="Score the story's optimistic/pessimistic tone.",
    children=[optimistic_tone]
)

dag = DeepAcyclicGraph(root_nodes=[tone])
tone_metric= DAGMetric(name="tone", dag=dag)