from deepeval.test_case import LLMTestCase
from deepeval.metrics import BiasMetric
from vividness import vividness_emotion_metric
from vivid_setting import vividness_setting_metric
from cognition import cognition_metric
from development import development_metric
from emo_shift import emo_shift_metric
from plot_volume import volume_metric
from resolution import resolution_metric
from tone import tone_metric
from vulnerability import vulnerability_metric

from 处理excel import read_story
import os
from openpyxl import Workbook,load_workbook

ori_path = r"C:\Users\27666\Desktop\项目数据\1GPT_data.xlsx"
save_path = r"C:\Users\27666\Desktop\实验室项目\deepeval测试用例\score2.xlsx"

#调用自定义函数处理数据集csv文件
stories = read_story(ori_path)

#生成存储数据的excel
workbook = Workbook()
sheet = workbook.active
sheet.title = "Scores"
sheet.append(['story','vividness_emotion','vividness_setting','vulnerability'
                           ,'tone','resolution','volume','emo_shift','development','cognition'])
workbook.save(save_path)

#加载工作簿
workbook = load_workbook(save_path)
sheet = workbook.active
i = 0

#自定义阈值
metric = BiasMetric(threshold=0.5)

#遍历数据集
for story in stories[65:70:1]:
    
    print(story)
    score = []
    score.append(i)
    
    #获得分数
    test_case = LLMTestCase(
    input="""生成一个故事""",
    actual_output= story)
    
    try:
        vividness_emotion_metric.measure(test_case,metric)
        # 检查分数是否为None
        if vividness_emotion_metric.score is None:
            raise ValueError("分数未正确计算")
        a = vividness_emotion_metric.score*10
    except Exception as e:
        print(f"情感生动性指标错误: {e}")
        a = "error"  # 错误时记0分
    print("情绪生动性：", a)
    score.append(a)
    
    vividness_setting_metric.measure(test_case,metric)
    a = vividness_setting_metric.score*10
    print("环境生动性：",vividness_setting_metric.score*10)
    score.append(a)
    
    vulnerability_metric.measure(test_case,metric)
    a = vulnerability_metric.score*10
    print("角色脆弱程度：",a)   
    score.append(a)

    try:
        tone_metric.measure(test_case,metric)
        # 检查分数是否为None
        if tone_metric.score is None:
            raise ValueError("分数未正确计算")
        a = tone_metric.score*10
    except Exception as e:
        print(f"语气情绪指标错误: {e}")
        a = "error"
    print("语气情绪：", a)
    score.append(a)
    
    resolution_metric.measure(test_case,metric)
    a = resolution_metric.score*10
    print("矛盾解决程度：",a)    
    score.append(a)
    
    try:
        volume_metric.measure(test_case,metric)
        # 检查分数是否为None
        if volume_metric.score is None:
            raise ValueError("分数未正确计算")
        a = volume_metric.score*10
    except Exception as e:
        print(f"情节体量指标错误: {e}")
        a = "error"  # 错误时记0分
    print("情节体量：", a)
    score.append(a)
    
    try:
        emo_shift_metric.measure(test_case,metric)
        # 检查分数是否为None
        if emo_shift_metric.score is None:
            raise ValueError("分数未正确计算")
        a = emo_shift_metric.score
    except Exception as e:
        print(f"情感转变性指标错误: {e}")
        a = "error"  # 错误时记0分
    print("情绪转变程度：", a)
    score.append(a)
    
    try:
        development_metric.measure(test_case,metric)
        # 检查分数是否为None
        if development_metric.score is None:
            raise ValueError("分数未正确计算")
        a = development_metric.score*10
    except Exception as e:
        print(f"角色发展指标错误: {e}")
        a = "error"  # 错误时记0分
    print("角色发展程度：", a)
    score.append(a)

    cognition_metric.measure(test_case,metric)
    a = cognition_metric.score*10
    print("认知表达丰富程度：",a)
    score.append(a)
    
    i=i+1
    sheet.append(score)
    workbook.save(save_path)