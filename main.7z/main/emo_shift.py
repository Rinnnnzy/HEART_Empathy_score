from deepeval.test_case import LLMTestCaseParams
from deepeval.metrics.dag import (
    DeepAcyclicGraph,
    TaskNode,
    BinaryJudgementNode,
    NonBinaryJudgementNode,
    VerdictNode,
)
from deepeval.metrics import DAGMetric

#明显情绪转变打分 非二叉
emotion_shifts=NonBinaryJudgementNode(
    criteria = "Rate the degree of emotional shifts in 'actual_output'.",
    children = [
        VerdictNode(verdict="no emotion shifts",score=1),
        VerdictNode(verdict="limited or trivial emotional shifts",score=2),
        VerdictNode(verdict="moderate emotional shifts",score=3),
        VerdictNode(verdict="significant emotional shifts",score=4),
        VerdictNode(verdict="life-altering, dramatic emotional shifts",score=5)
    ]
)

shift = TaskNode(
    instructions="Analyze the degree of emotional shifts of 'actual_output' based on decision tree analysis.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    output_label="Score the story's emotional shifts.",
    children=[emotion_shifts]
)

dag = DeepAcyclicGraph(root_nodes=[shift])
emo_shift_metric= DAGMetric(name="emo_shift", dag=dag)