from deepeval.test_case import LLMTestCaseParams
from deepeval.metrics.dag import (
    DeepAcyclicGraph,
    TaskNode,
    BinaryJudgementNode,
    NonBinaryJudgementNode,
    VerdictNode,
)
from deepeval.metrics import DAGMetric

#故事矛盾解决程度打分 非二叉
resolution = NonBinaryJudgementNode(
    criteria = "Resolution refers to the extent to which conflict is addressed and questions are answered by the end of the story.Rate the degree of resolution by the end of 'actual_output'.",
    children = [
        VerdictNode(verdict="no solution",score=1),
        VerdictNode(verdict="limited resolution",score=2),
        VerdictNode(verdict="moderate resolution",score=3),
        VerdictNode(verdict="significant resolution",score=4),
        VerdictNode(verdict="complete resolution",score=5)
    ]
)

resolution_ = TaskNode(
    instructions="Analyze the degree of resolution by the end of 'actual_output' based on decision tree analysis.",
    evaluation_params=[LLMTestCaseParams.ACTUAL_OUTPUT],
    output_label="Score the story's resolution.",
    children=[resolution]
)

dag = DeepAcyclicGraph(root_nodes=[resolution_])
resolution_metric= DAGMetric(name="resolution", dag=dag)