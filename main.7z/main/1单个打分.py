from deepeval.test_case import LLMTestCase
from deepeval.metrics import BiasMetric
from vividness import vividness_emotion_metric
from vivid_setting import vividness_setting_metric
from cognition import cognition_metric
from development import development_metric
from emo_shift import emo_shift_metric
from plot_volume import volume_metric
from resolution import resolution_metric
from tone import tone_metric
from vulnerability import vulnerability_metric

metric = BiasMetric(threshold=0.5)

#获得分数
test_case = LLMTestCase(
input="""今天我在中环帮一个华裔小男孩指路﹣交谈中他问我英语这么好是local还是华裔我说都不是，我来自大陆。他的10岁独自从波士顿飞来香港看赛马我的10岁在黄河故道的盐碱地里拾麦穗。请你根据这个人生经历生成一段分享感悟的文字""",
actual_output= """
看赛马是见世面，看过黄河、盐碱地也是见过世面，世面 是世界的每一面
""")
    
try:
    vividness_emotion_metric.measure(test_case,metric)
        # 检查分数是否为None
    if vividness_emotion_metric.score is None:
        raise ValueError("分数未正确计算")
    a = vividness_emotion_metric.score*10
except Exception as e:
    print(f"情感生动性指标错误: {e}")
    a = "error"  # 错误时记0分
print("情绪生动性：", a)
    
vividness_setting_metric.measure(test_case,metric)
a = vividness_setting_metric.score*10
print("环境生动性：",vividness_setting_metric.score*10)
    
vulnerability_metric.measure(test_case,metric)
a = vulnerability_metric.score*10
print("角色脆弱程度：",a)   

try:
        tone_metric.measure(test_case,metric)
        # 检查分数是否为None
        if tone_metric.score is None:
            raise ValueError("分数未正确计算")
        a = tone_metric.score*10
except Exception as e:
        print(f"语气情绪指标错误: {e}")
        a = "error"
print("语气情绪：", a)
    
resolution_metric.measure(test_case,metric)
a = resolution_metric.score*10
print("矛盾解决程度：",a)    
    
try:
        volume_metric.measure(test_case,metric)
        # 检查分数是否为None
        if volume_metric.score is None:
            raise ValueError("分数未正确计算")
        a = volume_metric.score*10
except Exception as e:
        print(f"情节体量指标错误: {e}")
        a = "error"  # 错误时记0分
print("情节体量：", a)
    
try:
        emo_shift_metric.measure(test_case,metric)
        # 检查分数是否为None
        if emo_shift_metric.score is None:
            raise ValueError("分数未正确计算")
        a = emo_shift_metric.score
except Exception as e:
        print(f"情感转变性指标错误: {e}")
        a = "error"  # 错误时记0分
print("情绪转变程度：", a*10)
    
try:
        development_metric.measure(test_case,metric)
        # 检查分数是否为None
        if development_metric.score is None:
            raise ValueError("分数未正确计算")
        a = development_metric.score*10
except Exception as e:
        print(f"角色发展指标错误: {e}")
        a = "error"  # 错误时记0分
print("角色发展程度：", a)

cognition_metric.measure(test_case,metric)
a = cognition_metric.score*10
print("认知表达丰富程度：",a)

