import pandas as pd
import os,pandas as pd


def read_story(path,num):
    df = pd.read_excel(path,header=None)
    column = df[num]
    
    story = [str(value) for _,value in column.items()]
    return story


def calculate_empathy_score(file_path, output_file_path):

    # 读取 Excel 文件
    data = pd.read_excel(file_path, sheet_name="Sheet1")
    # 自定义公式计算同理心得分
    def custom_formula(row):
        return (
            row['vividness_emotion'] * 0.5 +
            row['vividness_setting'] * 0.15 +
            row['vulnerability'] * 0.1 +
            row['cognition'] * 0.08 +
            row['tone'] * 0.05 +
            row['volume'] * 0.04 +
            row['resolution'] * 0.03 +
            row['development'] * 0.03 +
            row['emo_shift'] * 0.02
        )
    # 应用自定义公式并创建新列 'empathy_score'
    data['empathy_score'] = data.apply(custom_formula, axis=1)
    # 将结果写回到新的 Excel 文件
    data.to_excel(output_file_path, index=False)
    print("处理完成，结果已保存到:", output_file_path)